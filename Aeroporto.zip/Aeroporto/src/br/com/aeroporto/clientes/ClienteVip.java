package br.com.aeroporto.clientes;

public class ClienteVip extends Cliente {

	private double passagemBase;
	private int mensalidadeVip;
	private int tempoprivilegio;
	private double passagemVip;
	
	  public ClienteVip(String nome, int cpf, boolean passaporte, double pesoMala, double passagem, int mensalidadeVip, int tempoprivilegio) {
	        super(nome, cpf, passaporte, pesoMala, passagem);
	        this.mensalidadeVip = mensalidadeVip;
	        this.tempoprivilegio = tempoprivilegio;
	    }

	public int getMensalidadeVip() {
		return mensalidadeVip;
	}


	public void setMensalidadeVip(int mensalidadeVip) {
		this.mensalidadeVip = mensalidadeVip;
	}

	public int getTempoprivilegio() {
		return tempoprivilegio;
	}

	public void setTempoprivilegio(int tempoprivilegio) {
		this.tempoprivilegio = tempoprivilegio;
	}

	@Override
	public double comprarPassagem() {
		passagemBase = super.comprarPassagem();
		passagemVip = passagemBase * 0.80;
		return passagemVip;
	}
	
	public void imprimirPassagemVip() {
		System.out.println("------------------");
		System.out.println("Preço passagem com desconto Vip:");
		System.out.println("De " + passagemBase + "R$" + " Para " + passagemVip + "R$");
	}
	
	public void InfoClienteVip() {
		System.out.println("------------------");
		System.out.println("Informações do Cliente Vip:");
		System.out.println("Nome: " + getNome());
		System.out.println("CPF: " + getCpf());
		System.out.println("Passaporte: " + isPassaporte());
		System.out.println("Tempo de Vip: " + tempoprivilegio + " Meses.");
	}
	
	
}
