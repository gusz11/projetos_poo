package br.com.aeroporto.clientes;
import br.com.aeroporto.avioes.*;

public class Cliente {

	private String nome;
	private int cpf;
	private boolean passaporte;
	private double pesoMala;
	private double passagem;
	
	public Cliente(String nome, int cpf, boolean passaporte, double pesoMala, double passagem) {
		super();
		this.nome = nome;
		this.cpf = cpf;
		this.passaporte = passaporte;
		this.pesoMala = pesoMala;
		this.passagem = passagem;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public int getCpf() {
		return cpf;
	}

	public void setCpf(int cpf) {
		this.cpf = cpf;
	}

	public boolean isPassaporte() {
		return passaporte;
	}

	public void setPassaporte(boolean passaporte) {
		this.passaporte = passaporte;
	}

	public double getPesoMala() {
		return pesoMala;
	}

	public void setPesoMala(int pesoMala) {
		this.pesoMala = pesoMala;
	}
	
	
	public double getPassagem() {
		return passagem;
	}

	public void setPassagem(double passagem) {
		this.passagem = passagem;
	}

	public double comprarPassagem() {
		return passagem;
	}
	
	public void imprimirPassagem() {
		System.out.println("------------------");
		System.out.println("Preço Passagem:");
		System.out.println(passagem + "R$");
	}
	
	
	public void InfoCliente() {
		System.out.println("------------------");
		System.out.println("Informações do Cliente:");
		System.out.println("Nome: " + nome);
		System.out.println("CPF: " + cpf);
		System.out.println("Passaporte: " + passaporte);
	}
	
	 public double infoCapacidade(AviaoNacional aviao) {
			System.out.println("------------------");
		 	System.out.println("Informações sobre carga:");
	        System.out.println("Peso da mala: " + pesoMala + "KG");
	        System.out.println("Capacidade do avião: " + aviao.getCapacidade() + "KG");
	        double porcentagemCapacidade = ((double) pesoMala / aviao.getCapacidade()) * 100;
	        System.out.println("Porcentagem da capacidade usada: " + porcentagemCapacidade + "%");
	        return porcentagemCapacidade;
	    }
	}
	
