package br.com.aeroporto.main;
import br.com.aeroporto.clientes.*;
import br.com.aeroporto.avioes.*;

public class Main {

	public static void main(String[] args) {
		

		Cliente objCliente = new Cliente("Gustavo", 4533456, true, 13, 340.45);

		AviaoNacional objAviaoNacional = new AviaoNacional("A2345", "BA-DF", 500);
		objAviaoNacional.infoVoo();

		
		AviaoInternacional objAviaoInternacional = new AviaoInternacional("B8294", "JP-BR", 1000);
		objAviaoInternacional.infoVooInternacional();
		objAviaoInternacional.verificacaoVoo(objCliente);

	
		objCliente.InfoCliente();
		objCliente.infoCapacidade(objAviaoNacional);
		objCliente.imprimirPassagem();

		
		ClienteVip objClienteVip = new ClienteVip("Larissa", 0002345667, false, 12.3, 500.39, 30, 6);
		objClienteVip.InfoClienteVip();
		objClienteVip.comprarPassagem();
		objClienteVip.imprimirPassagemVip();

		
	}

}
