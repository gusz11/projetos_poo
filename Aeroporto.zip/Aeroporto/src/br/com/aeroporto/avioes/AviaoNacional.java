package br.com.aeroporto.avioes;

public class AviaoNacional {

	private String modeloAviao;
	private String percurso;
	private int capacidade;
	
	public AviaoNacional(String modeloAviao, String percurso, int capacidade) {
		super();
		this.modeloAviao = modeloAviao;
		this.percurso = percurso;
		this.capacidade = capacidade;
	}

	public String getModeloaviao() {
		return modeloAviao;
	}

	public void setModeloaviao(String modeloaviao) {
		this.modeloAviao = modeloaviao;
	}

	public String getPercurso() {
		return percurso;
	}

	public void setPercurso(String percurso) {
		this.percurso = percurso;
	}

	public int getCapacidade() {
		return capacidade;
	}

	public void setCapacidade(int capacidade) {
		this.capacidade = capacidade;
	}
	
	public void infoVoo() {
		System.out.println("------------------");
		System.out.println("Informações do Voo Nacional:");
		System.out.println("Modelo: " + modeloAviao);
		System.out.println("Percurso: " + percurso);
		System.out.println("Capacidade: " + capacidade + "KG");
		
	}
	
}
