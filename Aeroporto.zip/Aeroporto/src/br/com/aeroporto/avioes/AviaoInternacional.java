package br.com.aeroporto.avioes;
import br.com.aeroporto.clientes.*;

public class AviaoInternacional extends AviaoNacional {

    public AviaoInternacional(String modeloAviao, String percurso, int capacidade) {
        super(modeloAviao, percurso, capacidade);
    }

    
    public void infoVooInternacional() {
    	System.out.println("------------------");
		System.out.println("Informações do Voo Internacional:");
        System.out.println("Modelo: " + getModeloaviao());
        System.out.println("Percurso: " + getPercurso());
        System.out.println("Capacidade: " + getCapacidade()  + "KG");
    }
    
    public void verificacaoVoo(Cliente cliente) {
    	System.out.println("------------------");
		System.out.println("O Cliente " + cliente.getNome() + " tem permissão para o voo internacional?");
    	if (cliente.isPassaporte()) {
    		 System.out.println("Com permissão de voo.");
    	}
    	else {
    		 System.out.println("Sem permissão de voo");
    		}
    
    }
}
